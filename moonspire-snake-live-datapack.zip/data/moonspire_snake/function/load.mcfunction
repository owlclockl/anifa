scoreboard objectives add ms_snake dummy
execute unless score #installed ms_snake matches 0..1 run scoreboard players set #installed ms_snake 0
scoreboard players set #minus_one ms_snake -1
execute unless score #speed ms_snake matches 1..20 run scoreboard players set #speed ms_snake 4
