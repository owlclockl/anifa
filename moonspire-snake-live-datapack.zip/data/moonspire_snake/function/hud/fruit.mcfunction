execute positioned ~35 ~-51 ~76 run title @a[distance=..12] actionbar [{"text": "Яблоки: ", "color": "gold"}, {"score": {"name": "#score", "objective": "ms_snake"}}, {"text": " / 4"}]
