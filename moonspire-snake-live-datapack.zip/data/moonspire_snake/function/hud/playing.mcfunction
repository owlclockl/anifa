fill ~48 ~-78 ~3 ~50 ~-76 ~3 minecraft:redstone_block
execute positioned ~35 ~-51 ~76 run title @a[distance=..12] actionbar {"text": "Змейка ползёт сама · стрелки меняют направление", "color": "aqua"}
