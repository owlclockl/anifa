fill ~20 ~-78 ~3 ~22 ~-76 ~3 minecraft:redstone_block
