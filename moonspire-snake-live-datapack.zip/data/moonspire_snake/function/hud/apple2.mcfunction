fill ~8 ~-78 ~3 ~10 ~-76 ~3 minecraft:redstone_block
