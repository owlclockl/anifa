fill ~2 ~-78 ~3 ~4 ~-76 ~3 minecraft:redstone_block
