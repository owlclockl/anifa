fill ~14 ~-78 ~3 ~16 ~-76 ~3 minecraft:redstone_block
