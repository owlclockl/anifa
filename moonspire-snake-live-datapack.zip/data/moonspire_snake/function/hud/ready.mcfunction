execute positioned ~35 ~-51 ~76 run title @a[distance=..12] actionbar {"text": "Готово · нажми «Новая игра»", "color": "aqua"}
