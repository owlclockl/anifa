execute positioned ~35 ~-51 ~76 run title @a[distance=..12] actionbar {"text": "Столкновение · «Новая игра», чтобы повторить", "color": "red"}
