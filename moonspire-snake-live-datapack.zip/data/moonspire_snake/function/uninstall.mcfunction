execute in minecraft:overworld at @e[type=minecraft:marker,tag=moonspire_snake.origin,limit=1] if loaded ~ ~ ~4 if loaded ~16 ~ ~4 if loaded ~32 ~ ~4 if loaded ~48 ~ ~4 if loaded ~64 ~ ~4 if loaded ~71 ~ ~4 if loaded ~32 ~-39 ~78 if loaded ~38 ~-39 ~78 run return run function moonspire_snake:unbind
tellraw @s {"text":"Экран не подключён или его чанки не загружены.","color":"red"}
