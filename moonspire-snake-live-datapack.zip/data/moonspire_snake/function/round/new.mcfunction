function moonspire_snake:round/reset
scoreboard players set #mode ms_snake 1
function moonspire_snake:hud/playing
