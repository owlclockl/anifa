scoreboard players operation #timer ms_snake = #speed ms_snake
scoreboard players operation #nx ms_snake = #x ms_snake
scoreboard players operation #ny ms_snake = #y ms_snake
execute if score #queued ms_snake matches 0 run scoreboard players remove #ny ms_snake 1
execute if score #queued ms_snake matches 1 run scoreboard players add #nx ms_snake 1
execute if score #queued ms_snake matches 2 run scoreboard players add #ny ms_snake 1
execute if score #queued ms_snake matches 3 run scoreboard players remove #nx ms_snake 1
execute unless score #nx ms_snake matches 0..71 run return run function moonspire_snake:round/loss
execute unless score #ny ms_snake matches 0..71 run return run function moonspire_snake:round/loss
execute store result storage moonspire_snake:game next.x int 1 run scoreboard players get #nx ms_snake
execute store result storage moonspire_snake:game next.y int 1 run scoreboard players get #ny ms_snake
function moonspire_snake:fruit/detect
scoreboard players set #hold ms_snake 0
execute if score #grow ms_snake matches 1.. run scoreboard players set #hold ms_snake 1
execute if score #eat ms_snake matches 1 run scoreboard players set #hold ms_snake 1
function moonspire_snake:round/collision with storage moonspire_snake:game next
execute if score #mode ms_snake matches 3 run return 0
execute if score #hold ms_snake matches 0 run function moonspire_snake:pixel/dark with storage moonspire_snake:game body[-1]
execute if score #hold ms_snake matches 0 run data remove storage moonspire_snake:game body[-1]
execute if score #eat ms_snake matches 1 run function moonspire_snake:fruit/take
data modify storage moonspire_snake:game body prepend from storage moonspire_snake:game next
function moonspire_snake:pixel/light with storage moonspire_snake:game next
scoreboard players operation #x ms_snake = #nx ms_snake
scoreboard players operation #y ms_snake = #ny ms_snake
scoreboard players operation #dir ms_snake = #queued ms_snake
execute if score #grow ms_snake matches 1.. run scoreboard players remove #grow ms_snake 1
execute if score #score ms_snake matches 4.. run return run function moonspire_snake:round/win
execute if score #eat ms_snake matches 1 run function moonspire_snake:fruit/spawn
