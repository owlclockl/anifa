function moonspire_snake:clear
scoreboard players set #mode ms_snake 0
scoreboard players set #score ms_snake 0
scoreboard players set #grow ms_snake 0
scoreboard players set #x ms_snake 20
scoreboard players set #y ms_snake 35
scoreboard players set #dir ms_snake 1
scoreboard players set #queued ms_snake 1
scoreboard players set #timer ms_snake 30
data modify storage moonspire_snake:game body set value [{x:20,y:35},{x:19,y:35},{x:18,y:35},{x:17,y:35},{x:16,y:35},{x:15,y:35},{x:14,y:35},{x:13,y:35},{x:12,y:35},{x:11,y:35},{x:10,y:35},{x:9,y:35}]
fill ~9 ~-35 ~3 ~20 ~-35 ~3 minecraft:redstone_block
scoreboard players set #ax ms_snake 40
scoreboard players set #ay ms_snake 35
function moonspire_snake:fruit/accept
