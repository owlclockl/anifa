scoreboard players set #mode ms_snake 4
fill ~48 ~-78 ~3 ~50 ~-76 ~3 minecraft:air replace minecraft:redstone_block
fill ~48 ~-78 ~4 ~50 ~-76 ~4 minecraft:redstone_lamp[lit=false] replace minecraft:redstone_lamp
fill ~66 ~-78 ~3 ~68 ~-76 ~3 minecraft:redstone_block
function moonspire_snake:hud/won
