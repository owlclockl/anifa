$execute unless data storage moonspire_snake:game body[{x:$(x),y:$(y)}] run return 0
execute if score #hold ms_snake matches 1 run return run function moonspire_snake:round/loss
execute store result score #tx ms_snake run data get storage moonspire_snake:game body[-1].x 1
execute store result score #ty ms_snake run data get storage moonspire_snake:game body[-1].y 1
execute if score #nx ms_snake = #tx ms_snake if score #ny ms_snake = #ty ms_snake run return 0
function moonspire_snake:round/loss
