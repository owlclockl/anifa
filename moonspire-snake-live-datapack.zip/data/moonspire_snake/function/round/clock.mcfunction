scoreboard players remove #timer ms_snake 1
execute if score #timer ms_snake matches ..0 run function moonspire_snake:round/step
