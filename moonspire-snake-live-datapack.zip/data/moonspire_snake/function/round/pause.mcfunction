scoreboard players set #mode ms_snake 2
fill ~48 ~-78 ~3 ~50 ~-76 ~3 minecraft:air replace minecraft:redstone_block
fill ~48 ~-78 ~4 ~50 ~-76 ~4 minecraft:redstone_lamp[lit=false] replace minecraft:redstone_lamp
function moonspire_snake:hud/paused
