execute in minecraft:overworld at @e[type=minecraft:marker,tag=moonspire_snake.origin,limit=1] run function moonspire_snake:live_tick
