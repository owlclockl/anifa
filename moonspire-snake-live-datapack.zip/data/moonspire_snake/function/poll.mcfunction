scoreboard players set #edge_new ms_snake 0
execute if block ~32 ~-39 ~78 minecraft:stone_button[face=floor,facing=north,powered=true] run scoreboard players set #edge_new ms_snake 1
execute if score #edge_new ms_snake matches 1 run setblock ~32 ~-39 ~78 minecraft:stone_button[face=floor,facing=north,powered=false]
scoreboard players set #edge_up ms_snake 0
execute if block ~35 ~-39 ~77 minecraft:stone_button[face=floor,facing=north,powered=true] run scoreboard players set #edge_up ms_snake 1
execute if score #edge_up ms_snake matches 1 run setblock ~35 ~-39 ~77 minecraft:stone_button[face=floor,facing=north,powered=false]
scoreboard players set #edge_left ms_snake 0
execute if block ~34 ~-39 ~78 minecraft:stone_button[face=floor,facing=north,powered=true] run scoreboard players set #edge_left ms_snake 1
execute if score #edge_left ms_snake matches 1 run setblock ~34 ~-39 ~78 minecraft:stone_button[face=floor,facing=north,powered=false]
scoreboard players set #edge_down ms_snake 0
execute if block ~35 ~-39 ~79 minecraft:stone_button[face=floor,facing=north,powered=true] run scoreboard players set #edge_down ms_snake 1
execute if score #edge_down ms_snake matches 1 run setblock ~35 ~-39 ~79 minecraft:stone_button[face=floor,facing=north,powered=false]
scoreboard players set #edge_right ms_snake 0
execute if block ~36 ~-39 ~78 minecraft:stone_button[face=floor,facing=north,powered=true] run scoreboard players set #edge_right ms_snake 1
execute if score #edge_right ms_snake matches 1 run setblock ~36 ~-39 ~78 minecraft:stone_button[face=floor,facing=north,powered=false]
scoreboard players set #edge_pause ms_snake 0
execute if block ~38 ~-39 ~78 minecraft:stone_button[face=floor,facing=north,powered=true] run scoreboard players set #edge_pause ms_snake 1
execute if score #edge_pause ms_snake matches 1 run setblock ~38 ~-39 ~78 minecraft:stone_button[face=floor,facing=north,powered=false]
execute if score #edge_new ms_snake matches 1 run return run function moonspire_snake:round/new
execute if score #edge_pause ms_snake matches 1 if score #mode ms_snake matches 1 run return run function moonspire_snake:round/pause
execute if score #edge_pause ms_snake matches 1 if score #mode ms_snake matches 2 run return run function moonspire_snake:round/resume
execute if score #mode ms_snake matches 1..2 if score #edge_left ms_snake matches 1 unless score #dir ms_snake matches 1 run scoreboard players set #queued ms_snake 3
execute if score #mode ms_snake matches 1..2 if score #edge_down ms_snake matches 1 unless score #dir ms_snake matches 0 run scoreboard players set #queued ms_snake 2
execute if score #mode ms_snake matches 1..2 if score #edge_right ms_snake matches 1 unless score #dir ms_snake matches 3 run scoreboard players set #queued ms_snake 1
execute if score #mode ms_snake matches 1..2 if score #edge_up ms_snake matches 1 unless score #dir ms_snake matches 2 run scoreboard players set #queued ms_snake 0
execute if score #mode ms_snake matches 1 run function moonspire_snake:round/clock
