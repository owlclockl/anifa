function moonspire_snake:clear
scoreboard players set #mode ms_snake 0
scoreboard players set #installed ms_snake 0
kill @e[type=minecraft:marker,tag=moonspire_snake.origin,distance=..0.1,limit=1]
tellraw @s {"text":"Экран отключён.","color":"aqua"}
