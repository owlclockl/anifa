$setblock ~$(x) ~-$(y) ~3 minecraft:redstone_block
