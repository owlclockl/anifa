$setblock ~$(x) ~-$(y) ~3 minecraft:air
$setblock ~$(x) ~-$(y) ~4 minecraft:redstone_lamp[lit=false]
