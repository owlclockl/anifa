summon minecraft:marker ~ ~ ~ {Tags:["moonspire_snake.origin"]}
scoreboard players set #installed ms_snake 1
function moonspire_snake:round/reset
function moonspire_snake:hud/ready
tellraw @s {"text":"Экран подключён. Поднимись к пульту и нажми «Новая игра».","color":"aqua"}
