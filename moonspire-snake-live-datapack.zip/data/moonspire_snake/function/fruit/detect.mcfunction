scoreboard players set #eat ms_snake 0
execute unless score #fruit ms_snake matches 1 run return 0
scoreboard players operation #delta_x ms_snake = #nx ms_snake
scoreboard players operation #delta_x ms_snake -= #ax ms_snake
execute if score #delta_x ms_snake matches ..-1 run scoreboard players operation #delta_x ms_snake *= #minus_one ms_snake
scoreboard players operation #delta_y ms_snake = #ny ms_snake
scoreboard players operation #delta_y ms_snake -= #ay ms_snake
execute if score #delta_y ms_snake matches ..-1 run scoreboard players operation #delta_y ms_snake *= #minus_one ms_snake
scoreboard players operation #delta_x ms_snake += #delta_y ms_snake
execute if score #delta_x ms_snake matches ..2 run scoreboard players set #eat ms_snake 1
