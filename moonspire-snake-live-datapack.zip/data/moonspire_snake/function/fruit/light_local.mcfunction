fill ~ ~-2 ~ ~ ~-2 ~ minecraft:redstone_block
fill ~-1 ~-1 ~ ~1 ~-1 ~ minecraft:redstone_block
fill ~-2 ~ ~ ~2 ~ ~ minecraft:redstone_block
fill ~-1 ~1 ~ ~1 ~1 ~ minecraft:redstone_block
fill ~ ~2 ~ ~ ~2 ~ minecraft:redstone_block
