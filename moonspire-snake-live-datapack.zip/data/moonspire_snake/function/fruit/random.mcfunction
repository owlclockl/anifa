scoreboard players remove #tries ms_snake 1
execute store result score #ax ms_snake run random value 2..69
execute store result score #ay ms_snake run random value 2..69
function moonspire_snake:fruit/candidate
execute if score #free ms_snake matches 1 run return run function moonspire_snake:fruit/accept
execute if score #tries ms_snake matches 1.. run return run function moonspire_snake:fruit/random
scoreboard players set #ax ms_snake 3
scoreboard players set #ay ms_snake 3
function moonspire_snake:fruit/fallback
