scoreboard players set #fruit ms_snake 1
execute store result storage moonspire_snake:game apple.x int 1 run scoreboard players get #ax ms_snake
execute store result storage moonspire_snake:game apple.y int 1 run scoreboard players get #ay ms_snake
function moonspire_snake:fruit/light with storage moonspire_snake:game apple
