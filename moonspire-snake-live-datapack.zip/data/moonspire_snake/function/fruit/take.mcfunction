function moonspire_snake:fruit/dark with storage moonspire_snake:game apple
scoreboard players set #fruit ms_snake 0
scoreboard players add #score ms_snake 1
scoreboard players add #grow ms_snake 4
execute if score #score ms_snake matches 1 run function moonspire_snake:hud/apple1
execute if score #score ms_snake matches 2 run function moonspire_snake:hud/apple2
execute if score #score ms_snake matches 3 run function moonspire_snake:hud/apple3
execute if score #score ms_snake matches 4 run function moonspire_snake:hud/apple4
function moonspire_snake:hud/fruit
