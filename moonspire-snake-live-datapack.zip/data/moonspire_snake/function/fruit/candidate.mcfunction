scoreboard players set #free ms_snake 1
execute store result storage moonspire_snake:game candidate.x int 1 run scoreboard players get #ax ms_snake
execute store result storage moonspire_snake:game candidate.y int 1 run scoreboard players get #ay ms_snake
function moonspire_snake:fruit/test with storage moonspire_snake:game candidate
