function moonspire_snake:fruit/candidate
execute if score #free ms_snake matches 1 run return run function moonspire_snake:fruit/accept
scoreboard players add #ax ms_snake 6
execute if score #ax ms_snake matches 70.. run scoreboard players add #ay ms_snake 6
execute if score #ax ms_snake matches 70.. run scoreboard players set #ax ms_snake 3
execute if score #ay ms_snake matches ..69 run function moonspire_snake:fruit/fallback
