$execute positioned ~$(x) ~-$(y) ~3 run function moonspire_snake:fruit/dark_local
