scoreboard players set #tries ms_snake 16
function moonspire_snake:fruit/random
