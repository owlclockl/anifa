scoreboard players set #speed ms_snake 4
tellraw @s {"text":"Лунная змейка: один шаг за 4 тиков.","color":"aqua"}
