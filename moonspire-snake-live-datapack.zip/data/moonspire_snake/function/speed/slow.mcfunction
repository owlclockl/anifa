scoreboard players set #speed ms_snake 8
tellraw @s {"text":"Лунная змейка: один шаг за 8 тиков.","color":"aqua"}
