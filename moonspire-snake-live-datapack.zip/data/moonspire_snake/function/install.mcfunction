execute in minecraft:overworld align xyz run function moonspire_snake:check_board
